package br.com.marka.android.riobel.model

import org.json.JSONObject

class User(
    var id: String? = null,
    var company: String? = null,
    var email: String? = null,
    var name: String? = null,
    var type: String? = null,

    var jsonObject: JSONObject? = null) {
}