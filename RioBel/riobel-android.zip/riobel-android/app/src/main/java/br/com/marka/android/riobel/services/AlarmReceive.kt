package br.com.marka.android.riobel.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceive : BroadcastReceiver() {

    override fun onReceive(context: Context?, p1: Intent?) {
        Log.e("Service_call_", "You are in AlarmReceive class.")
//        val background = Intent(context, LocationTrackingService::class.java)
        Log.e("AlarmReceive ", "testing called broadcast called")
//        context!!.startService(background)
    }
}