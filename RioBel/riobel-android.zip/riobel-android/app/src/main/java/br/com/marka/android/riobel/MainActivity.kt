package br.com.marka.android.riobel

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.SearchEvent
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.core.app.ActivityCompat
import br.com.marka.android.riobel.model.UrlServer
import br.com.marka.android.riobel.model.User
import br.com.marka.android.riobel.utils.Utils
import br.com.marka.android.riobel.utils.mUrl
import com.google.android.material.snackbar.Snackbar
import okhttp3.*
import org.json.JSONObject
import java.io.IOException


class MainActivity : AppCompatActivity() {

    private val TAG = MainActivity::class.java.simpleName

    private var mWebView: WebView? = null
    private var progressBar: ProgressBar? = null
    private var alarmManager: AlarmManager? = null
    internal var stop: Button? = null
    private var pendingIntent: PendingIntent? = null
    private var userId: String? = null
    private val mUrlServer: UrlServer? = null
    private val okHttpClient = OkHttpClient()
    private val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    private var mAlreadyStartedService = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        OneSignal.startInit(this)
//                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
//                .unsubscribeWhenNoonPageStartedtificationsAreDisabled(true)
//                .autoPromptLocation(true)
//                .init();

//        if (!checkPermission())
//            requestPermission()

        initViews()
        doLoadRequest()
    }

    /**
     * Step 1: Check Google Play services
     */
    private fun startStep1() {
        //Check whether this user has installed Google play service which is being used by Location updates.
        if (isGooglePlayServicesAvailable()) {
            //Passing null to indicate that it is executing for the first time.
            startStep2(null)
        } else
            Toast.makeText(applicationContext, R.string.no_google_playservice_available, Toast.LENGTH_LONG).show()

    }

    /**
     * Step 2: Check & Prompt Internet connection
     */
    private fun startStep2(dialog: DialogInterface?): Boolean {
        if (checkPermissions()) { //Yes permissions are granted by the user. Go to the next step.
            startStep3()
        } else {  //No user has not granted the permissions yet. Request now.
            requestPermissions()
        }
        return true
    }

    /**
     * Step 3: Start the Location Monitor Service
     */
    private fun startStep3() {
        //And it will be keep running until you close the entire application from task manager.
        //This method will executed only once.
        if (!mAlreadyStartedService) {
//            Log.i(TAG, String.valueOf(R.string.msg_location_service_started))
            //Start location sharing service to app server.........
//            val intent = Intent(this, LocationMonitoringService::class.java)
            startService(intent)
            mAlreadyStartedService = true
            //Ends................................................
        }
    }

    private fun requestPermissions() {

        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )

        val shouldProvideRationale2 = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )


        // Provide an additional rationale to the img_user. This would happen if the img_user denied the
        // request previously, but didn't check the "Don't ask again" checkbox.
        if (shouldProvideRationale || shouldProvideRationale2) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar(R.string.permission_rationale,
                android.R.string.ok, View.OnClickListener {
                    // Request permission
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ),
                        REQUEST_PERMISSIONS_REQUEST_CODE
                    )
                })
        } else {
            Log.i("Resquest Location...", "Requesting permission")
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the img_user denied the permission
            // previously and checked "Never ask again".
            ActivityCompat.requestPermissions(
                this@MainActivity,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_PERMISSIONS_REQUEST_CODE
            )
        }
    }

    private fun sendLocationUpdates(longitude: String, latitude: String) {
        val userId = Utils.readFromPreferences(applicationContext, "UserSAVED", "null")
        if (userId !== "null" && userId!!.length != 0) {
            val url = "http://adm.bunker.mk/wsjson/LATLNG.do?lat=$latitude&long=$longitude&UserID=$userId"
            doSendGetRequest(url)
        } else {
            Log.d(TAG, "The user no logged...")
        }
    }

    /**
     * Return the availability of GooglePlayServices
     */
    fun isGooglePlayServicesAvailable(): Boolean {
//        val googleApiAvailability = GoogleApiAvailability.getInstance()
//        val status = googleApiAvailability.isGooglePlayServicesAvailable(this)
//        if (status != ConnectionResult.SUCCESS) {
//            if (googleApiAvailability.isUserResolvableError(status)) {
//                googleApiAvailability.getErrorDialog(this, status, 2404).show()
//            }
//            return false
//        }
        return true
    }

    /**
     * Return the current state of the permissions needed.
     */
    private fun checkPermissions(): Boolean {
        val permissionState1 = ActivityCompat.checkSelfPermission(
            this,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )

        val permissionState2 = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        return permissionState1 == PackageManager.PERMISSION_GRANTED && permissionState2 == PackageManager.PERMISSION_GRANTED

    }


    /**
     * Callback received when a permissions request has been completed.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int, @NonNull permissions: Array<String>,
        @NonNull grantResults: IntArray
    ) {
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.size <= 0) {
                // If img_user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.i(TAG, "User interaction was cancelled.")
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Log.i(TAG, "Permission granted, updates requested, starting location updates")
                startStep3()

            } else {
                // Permission denied.

                // Notify the img_user via a SnackBar that they have rejected a core permission for the
                // app, which makes the Activity useless. In a real app, core permissions would
                // typically be best requested during a welcome-screen flow.

                // Additionally, it is important to remember that a permission might have been
                // rejected without asking the img_user for permission (device policy or "Never ask
                // again" prompts). Therefore, a img_user interface affordance is typically implemented
                // when permissions are denied. Otherwise, your app could appear unresponsive to
                // touches or interactions which have required permissions.
                showSnackbar(R.string.permission_denied_explanation,
                    R.string.settings, View.OnClickListener {
                        // Build intent that displays the App settings screen.
                        val intent = Intent()
                        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        val uri = Uri.fromParts(
                            "package",
                            BuildConfig.APPLICATION_ID, null
                        )
                        intent.data = uri
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                    })
            }
        }
    }

    private fun showSnackbar(mainTextStringId: Int, actionStringId: Int, listener: View.OnClickListener) {
        Snackbar.make(
            findViewById(android.R.id.content),
            getString(mainTextStringId),
            Snackbar.LENGTH_INDEFINITE
        )
            .setAction(getString(actionStringId), listener).show()
    }

    fun doLoadRequest() {
        val isConnected = Utils.isNetworkConnected(applicationContext)
        if (!isConnected) {
            Toast.makeText(this, "Falta de Conexão!", Toast.LENGTH_SHORT).show()
            return
        }

        loadContent(mUrl.trim())
    }

    fun doSendGetRequest(url: String) {
        Log.d(TAG, "Sending Settings to Duque Server...")
        val isConnected = Utils.isNetworkConnected(applicationContext)
        if (!isConnected) {
            Toast.makeText(this, "Falta de Conexão!", Toast.LENGTH_SHORT).show()
            return
        }

        val request = Request.Builder()
            .url(url)
            .build()

        okHttpClient.newCall(request)
            .enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // Error
                    runOnUiThread {
                        //                                Toast.makeText(MainActivity.this, "Erro de Comunicação!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Throws(IOException::class)
                override fun onResponse(call: Call, response: Response) {
                    val result = response.body()!!.string()

                }
            })
    }

    private fun checkPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true
        }
        for (permission in Utils.REQUEST_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) !== PackageManager.PERMISSION_GRANTED) {
                return false
            }
        }
        return true
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(this, Utils.REQUEST_PERMISSIONS, Utils.REQUEST_PERMISSION_CODE)
    }

    private fun loadContent(url: String) {
        val isConnected = Utils.isNetworkConnected(applicationContext)
        if (mWebView != null) {
            if (isConnected) {
                if (url != "")
                    mWebView!!.loadUrl(url.trim { it <= ' ' })
                else
                    Toast.makeText(applicationContext, "Erro no carregamento da página!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(applicationContext, "Sem Conexão!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun initViews() {
        progressBar = findViewById<ProgressBar>(R.id.progress)
        mWebView = findViewById<WebView>(R.id.mwebview)
        mWebView!!.getSettings().javaScriptEnabled = true
        mWebView!!.getSettings().cacheMode = WebSettings.LOAD_NO_CACHE
        mWebView!!.getSettings().setAppCacheEnabled(false)
        mWebView!!.getSettings().loadsImagesAutomatically = true
        mWebView!!.getSettings().loadWithOverviewMode = true
        mWebView!!.getSettings().useWideViewPort = true
        mWebView!!.getSettings().builtInZoomControls = false

        mWebView!!.setWebChromeClient(WebChromeClient())
        mWebView!!.setWebViewClient(CustomWebViewClient())
    }

    private inner class CustomWebViewClient : WebViewClient() {

        private val cookies: String? = null
        private val user: User? = null
        private val userObj: JSONObject? = null

        fun getCookie(url: String, cookieName: String): String? {
            var CookieValue: String? = null

            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.setAcceptThirdPartyCookies(mWebView, true)
            } else {
                cookieManager.setAcceptCookie(true)
            }

            val cookies = cookieManager.getCookie(url)
            val temp = cookies.split(";".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            for (ar1 in temp) {
                if (ar1.indexOf(cookieName) == 0) {
                    val temp1 = ar1.split("=".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    CookieValue = temp1[1]
                    break
                }
            }
            return CookieValue
        }

        override fun onPageFinished(view: WebView, url: String) {
            progressBar!!.setVisibility(View.GONE)
            this@MainActivity.progressBar!!.setProgress(100)

            //            // Get Data Cookies objects
            //            if (url.contains("log=1")) {
            //                cookies =  getCookie(url, "POSTOS_VALLE");
            //                try {
            //                    cookies = URLDecoder.decode(cookies, "UTF-8");
            //                    user = Json.toUser(cookies);
            //                } catch (UnsupportedEncodingException e) {
            //                    e.printStackTrace();
            //                }
            //                OneSignal.sendTags(user.jsonObject);
            //                if (!user.email.isEmpty() && user.email.length() > 0)
            //                    OneSignal.setEmail(user.email);
            //
            //                Utils.saveToPreference(getApplicationContext(), "UserSAVED", user.id);
            //                Log.i("OneSignal", "Tags Sent.......");
            //            }

            super.onPageFinished(view, url)
        }

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)

            //            // Intecept Data Valiables objects
            if (url.contains("waze://")) {
                var intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } else {
                    intent =
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.waze"))
                    startActivity(intent)
                }
                view.stopLoading()
            }
            //            //  https://maps.google.com/
            if (url.contains("maps.google.com")) {
                var intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } else {
                    intent =
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.waze"))
                    startActivity(intent)
                }
                view.stopLoading()
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            progressBar!!.setVisibility(View.VISIBLE)
            this@MainActivity.progressBar!!.setProgress(0)
            super.onPageStarted(view, url, favicon)
        }

    }

    override fun onBackPressed() {
        if (mWebView!!.canGoBack()) {
            mWebView!!.goBack()
            return
        }
        // Otherwise defer to system default behavior.
        super.onBackPressed()
    }

}
