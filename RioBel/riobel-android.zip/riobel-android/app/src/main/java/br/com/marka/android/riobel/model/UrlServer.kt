package br.com.marka.android.riobel.model

class UrlServer(var urlDefault: String? = null,
                var url2: String? = null,
                var url3: String? = null,
                var url4: String? = null )