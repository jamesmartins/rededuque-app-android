package br.com.marka.android.riobel.utils

val LOCATION_INTERVAL = 10000
val FASTEST_LOCATION_INTERVAL = 5000

val mUrl = "https://adm.bunker.mk/app/intro.do?key=Ngqx3ZAbiK8%C2%A2"
//val mUrlBR = "https://adm.bunkerapp.com.br/app/intro.do?key=Ngqx3ZAbiK8%C2%A2"
//    public static final String mUrl = "http://adm.bunker.mk/app/intro.do?key=jsop%C2%A369XkOztMd8KYuTjqkQ%C2%A2%C2%A2";
val mUrlDev = "https://adm.bunker.mk/app/intro.do?key=Ngqx3ZAbiK8%C2%A2"

val mUrlRestServer = "http://adm.bunker.mk/wsjson"
val mUrlService = "/url_dinamico.do"