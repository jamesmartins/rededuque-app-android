package br.com.marka.android.riobel.utils

// Novissima (muito impacto)
// 15/09/2023 = 2024
val mUrlStatic = "https://adm.bunkerapp.com.br/app/intro.do?key=Ngqx3ZAbiK8¢"
val mUrl = "https://adm.bunkerapp.com.br/app/intro.do?key=Ngqx3ZAbiK8¢"

val mUrlServices = "https://adm.bunker.mk/wsjson/"
val mUrlDecriptService = "https://adm.bunker.mk/wsjson/CookieDec.do"
val mUrlUserSearchKeyData = "https://adm.bunker.mk/wsjson/ConsultaCli.do"
val mUrlUserPushDataInformation = "https://adm.bunker.mk/wsjson/TokenAppPush.do"

const val FIRST_LOGIN_DONE = "FIRST_LOGIN_DONE"
const val VERIFY_KEY_CUSTOMER = "VERIFY_KEY_CUSTOMER"
const val PROJECT_ID = 21  // ID NUMBER RIO BEL PROJECT