package br.com.marka.android.riobel.parse

import br.com.marka.android.riobel.model.UrlServer
import br.com.marka.android.riobel.model.User
import org.json.JSONException
import org.json.JSONObject

object Json {
    fun toUser(json: String): User {
        try {
            val obj = JSONObject(json)
            val user = User()
            user.id = obj.getString("RD_userId")
            user.company = obj.getString("RD_userCompany")
            user.email = obj.getString("RD_userMail")
            user.name = obj.getString("RD_userName")
            user.type = obj.getString("RD_userType")
            user.jsonObject = obj
            return user
        } catch (e: JSONException) {
            throw RuntimeException(e)
        }

    }

    fun toJsonObject(json: String): JSONObject? {
        try {
            return JSONObject(json)
        } catch (e: JSONException) {
            e.printStackTrace()
            return null
        }

    }

    fun toUrlServer(json: String): UrlServer {
        try {
            val obj = JSONObject(json)
            val urlServer = UrlServer()
            urlServer.urlDefault = obj.getString("URL1")
            urlServer.url2 = obj.getString("URL2")
            urlServer.url3 = obj.getString("URL3")
            urlServer.url4 = obj.getString("URL4")
            return urlServer
        } catch (e: JSONException) {
            throw RuntimeException(e)
        }

    }
}